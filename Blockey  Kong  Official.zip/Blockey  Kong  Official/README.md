# Ada-Fuzzball Slam

Welcome to Ada’s Ada Fuzzball Slam, your second programming launchpad challenge.  This is a JS game using P5 and Matter.  

In small teams, you have been asked to complete the development of Ada’s new game “Fuzzball Slam”. Achieving this challenge will require you to incorporate new material (discussed and signposted this week) as well as building on the work you’ve already undertaken and demonstrate your ability to communicate, analyse and decompose a variety of different problems including research, testing, and debugging potential solutions with regards to aspects like the programming language, objects, classes, libraries, and frameworks. 

To complete this task, you will need to work together to discuss and test your ideas before deciding and implementing those that you developed into a workable solution
