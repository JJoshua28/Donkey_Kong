let ladderWin = null;
let ladder1 = null;
let ladder2 = null;
let ladder3 = null;
let ladder4 = null;
let ladder5 = null;

let ladderList = [];


class Ladders extends MasterClass{
	constructor(x, y, width, height, label) {
        super(x, y, width, height)
		let options = {
			isStatic: true,
			isSensor: true,
			restitution: 0,
			friction: 0,
			density: 1,
			label,
			collisionFilter: {
				category: 0x0008
			}
		}
		//create the body
		this.sensor = Matter.Bodies.rectangle(x, y, width, height, options);
		Matter.World.add(world, this.sensor); //add to the matter world
		this.addedToScore = false;
	}
	increaseScore () {
		if(this.addedToScore === false) {
			score += 200;
			this.addedToScore = true;
		}
	}

	show() {
		let pos = this.sensor.position; //create an shortcut alias 
		rectMode(CENTER); //switch centre to be centre rather than left, top
		noStroke()
		fill('#0000ff'); //set the fill colour
		rect(pos.x, pos.y, this.width, this.height); //draw the rectangle
	}

}

function displayLadderList (arr) {
    arr.forEach(element => {
        element.show();
    });
}

